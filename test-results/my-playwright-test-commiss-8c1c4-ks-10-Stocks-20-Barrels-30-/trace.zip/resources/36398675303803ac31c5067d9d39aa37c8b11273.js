(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_6f6a787c._.js",
  "static/chunks/src_a50a27b0._.js"
],
    source: "dynamic"
});
